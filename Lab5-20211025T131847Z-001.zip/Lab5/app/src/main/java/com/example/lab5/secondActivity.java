package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;

public class secondActivity extends AppCompatActivity {
    int marks;
    RadioGroup rg2;
    final static String totalMarks="total marks";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        rg2=findViewById(R.id.group2ID);
        Intent myIntent=getIntent();
        marks=myIntent.getIntExtra(firstActivity.marksFromQusOne, 0);
    }

    public void Qus2submitButtonFunction(View view) {
        int selectButton=rg2.getCheckedRadioButtonId();
        if(selectButton==R.id.qus2OneRdone || selectButton==R.id.qus2OneRdtwo || selectButton==R.id.qus2OneRdThree || selectButton==R.id.qus2OneRdFour){
            if(selectButton==R.id.qus2OneRdFour){
                marks = marks + 5;
            }else{
                marks = marks + 0;
            }
            Intent myIntent=new Intent(this, ThirdActivity.class);
            myIntent.putExtra(totalMarks,marks);
            startActivity(myIntent);
            //Toast.makeText(this, "+marks", Toast.LENGTH_SHORT).show();

        }else {
            Toast.makeText(this, "Please select first", Toast.LENGTH_SHORT).show();
        }
    }
    public void Qus2PreButtonFunction(View view) {
        Intent myIntent=new Intent(this, firstActivity.class);
        startActivity(myIntent);
    }
}