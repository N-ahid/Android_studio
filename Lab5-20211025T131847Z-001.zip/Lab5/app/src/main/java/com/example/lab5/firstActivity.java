package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;

public class firstActivity extends AppCompatActivity {
    RadioGroup rg;
    int marks;

    final static String marksFromQusOne="from first activity" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rg=findViewById(R.id.groupID);
    }

    public void Qus1NextButtonFunction(View view) {
        int selectButton=rg.getCheckedRadioButtonId();
        if(selectButton==R.id.qusOneRdone || selectButton==R.id.qusOneRdtwo || selectButton==R.id.qusOneRdThree || selectButton==R.id.qusOneRdFour){
            if(selectButton==R.id.qusOneRdone){
                marks = 5;
            }else{
                marks = 0;
            }
            Intent myIntent=new Intent(this, secondActivity.class);
            myIntent.putExtra(marksFromQusOne, marks);
            startActivity(myIntent);
            //Toast.makeText(this, "+marks", Toast.LENGTH_SHORT).show();

        }else {
            Toast.makeText(this, "Please select first", Toast.LENGTH_SHORT).show();
        }
    }
}