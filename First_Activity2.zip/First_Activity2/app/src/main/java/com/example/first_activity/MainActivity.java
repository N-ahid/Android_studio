package com.example.first_activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void BmiRadioBtnFunction(View view) {
        if(view.getId() == R.id.BmiRadioBtnID){
            Intent myIntent = new Intent(this,BMI_Activity.class);
            startActivity(myIntent);
        }
    }

    public void CurrencyRadioBtnFunction(View view) {
        if(view.getId() == R.id.BmiRadioBtnID){
            Intent myIntent = new Intent(this,BMI_Activity.class);
            startActivity(myIntent);
        }


    }
}