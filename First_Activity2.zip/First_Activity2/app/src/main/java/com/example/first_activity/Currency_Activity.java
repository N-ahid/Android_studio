package com.example.first_activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Currency_Activity extends AppCompatActivity {
    EditText myEditText;
    Double num, result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency2);
        myEditText = findViewById(R.id.BdtEditTextID);
    }

    public void RadioBtnFunction(View view) {
      num = myEditText.getText().toString()
    }
    }

