package com.example.myloginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class BMIActivity extends AppCompatActivity {
    EditText height_edit_text,weight_edit_text;
    Double result,height,weight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmiactivity);
        height_edit_text=findViewById(R.id.HeightEditTextId);
        weight_edit_text=findViewById(R.id.WeightEditTextId);
    }

    public void BMICalculatefunction(View view) {
        height=Double.parseDouble(height_edit_text.getText().toString());
        weight=Double.parseDouble(weight_edit_text.getText().toString());
        result=((weight)/(height*height));
        Toast.makeText(this, "BMI is"+result, Toast.LENGTH_SHORT).show();

    }
}