package com.example.myloginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }

    public void QuizBtnFunction(View view) {
        Intent myIntent = new Intent(this, QuizActivity.class);
        startActivity(myIntent);
    }

    public void BmiBtnFunction(View view) {
        Intent myIntent = new Intent(this, BMIActivity.class);
        startActivity(myIntent);
    }

    public void CurrencyConvertFunction(View view) {
        Intent myIntent = new Intent(this, CurrencyConvertActivity.class);
        startActivity(myIntent);
    }
}