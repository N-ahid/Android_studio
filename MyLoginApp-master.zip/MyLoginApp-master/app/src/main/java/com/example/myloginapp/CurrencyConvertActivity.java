package com.example.myloginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class CurrencyConvertActivity extends AppCompatActivity {
    EditText myedittext;
    TextView mytextview;
    Double result,number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency_convert);
        myedittext=findViewById(R.id.ThirdActivityEditTextId);
        mytextview=findViewById(R.id.ThirdActivityTextViewId);
    }


    public void BdtToUsdFunction(View view) {
        number=Double.parseDouble(myedittext.getText().toString());
        result=number/86.11;
        mytextview.setText("BDT "+number +"tk="+result+"USD");
    }

    public void BdtToRupeeFunction(View view) {
        number=Double.parseDouble(myedittext.getText().toString());
        result=number/1.15;
        mytextview.setText("BDT "+number +"tk="+result+"Rupee");
    }
}