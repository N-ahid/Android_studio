package com.example.myloginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class QuizActivity extends AppCompatActivity {
    TextView textView;
    int marks;
    RadioGroup rg;
    //int marks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        textView=findViewById(R.id.quizresulttextviewid);
        rg=findViewById(R.id.groupID);
    }

    public void Qus1NextButtonFunction(View view) {
        int selectButton=rg.getCheckedRadioButtonId();
        if(selectButton==R.id.qusOneRdone || selectButton==R.id.qusOneRdtwo || selectButton==R.id.qusOneRdThree || selectButton==R.id.qusOneRdFour){
            if(selectButton==R.id.qusOneRdone){
                marks = 5;
                textView.setText("you got "+marks+" out of 5");
                //Toast.makeText(this, "+marks", Toast.LENGTH_SHORT).show();
            }else{
                marks = 0;
                textView.setText("you got "+marks+" out of 5");
                //Toast.makeText(this, "+marks", Toast.LENGTH_SHORT).show();
            }



        }else {
            Toast.makeText(this, "Please select first", Toast.LENGTH_SHORT).show();
        }

    }

}