package com.example.lab2evaluation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText editText1,editText2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1=findViewById(R.id.FirstNameEditTextId);
        editText2=findViewById(R.id.LastNameEditTextId);
    }

    public void SubmitFunction(View view) {
        String firstname;
        firstname = editText1.getText().toString();
        String lastname;
        lastname = editText2.getText().toString();
        Toast.makeText(this, firstname+" "+lastname, Toast.LENGTH_SHORT).show();
    }
}